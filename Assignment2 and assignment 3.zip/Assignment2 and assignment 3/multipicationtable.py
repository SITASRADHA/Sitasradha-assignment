def multipication_table(n):
    for i in range(1,11):
        print(f"{n}*{i}={n*i}")
        
        
n=int(input("enter a number"))
print(multipication_table(n))
        