#sort series by value descending
import pandas as pd
series=pd.Series([1,7,8,4,5,6])
sort_series=series.sort_values(ascending=False)
print(sort_series)