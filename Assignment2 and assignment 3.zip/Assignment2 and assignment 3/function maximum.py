def maximum(a,b,c):
    if(a>b and a>c):
        print("a is maximum")
    elif(b>a and b>c):
        print("b is maximum")
    else:
        print("c is maximum")

a=int(input("enter first number"))
b=int(input("enter second number"))
c=int(input("enter third number"))

maximum(a,b,c)