#stack 2 arrays vertically
import numpy as np
arr1=np.array([1,2,3,4])
arr2=np.array([5,6,7,8])
stack_array=np.vstack((arr1,arr2))
print(stack_array)