#generate array from 0 to10
import numpy as np
arr=np.arange(0,11)
print(arr)