#check for null values
import pandas as pd
import numpy as np
series=pd.Series([1,2,np.nan,5,7,np.nan])
null_series=series.notnull()
print(null_series)
null_series=series.isnull()
print(null_series)