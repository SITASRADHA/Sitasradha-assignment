class Person:
    def _init_(self):
        self.name = None
        self.age = None

    def set_attributes(self, name, age):
        self.name = name
        self.age = age

    def display_info(self):
        print(f"Name: {self.name}")
        print(f"Age: {self.age}")

# Create an object
person = Person()

# Set attributes
person.set_attributes("John Doe", 30)

# Display information
person.display_info()