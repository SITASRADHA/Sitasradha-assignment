
class Rectangle:
    def _init_(self, length=0, width=0):
        self.length = length
        self.width = width

    def area(self):
        return self.length * self.width

    def perimeter(self):
        return 2 * (self.length + self.width)

    def set_dimensions(self, length, width):
        self.length = length
        self.width = width

    def get_dimensions(self):
        return self.length, self.width


# Example usage:
rect = Rectangle(5, 3)
print("Area:", rect.area())         # Output: Area: 15
print("Perimeter:", rect.perimeter())  # Output: Perimeter: 16

rect.set_dimensions(10, 4)
print("New dimensions:", rect.get_dimensions())  # Output: New dimensions: (10, 4)
print("New area:", rect.area())                   # Output: New area: 40
print("New perimeter:", rect.perimeter())         # Output: New perimeter: 28