#concatenate two series using concat()
import pandas as pd
series1=pd.Series([1,2,3,4])
series2=pd.Series([5,6,7,8])
concat_series=pd.concat([series1,series2])
print(concat_series)
