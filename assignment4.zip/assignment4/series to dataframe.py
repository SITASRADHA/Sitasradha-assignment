#convert series to dataframe
import pandas as pd
series=pd.Series([3,7,8,9,6,5,4,3])
dataframe_series=series.to_frame()
print(dataframe_series)
