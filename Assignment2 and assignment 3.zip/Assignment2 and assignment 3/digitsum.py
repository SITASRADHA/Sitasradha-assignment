def digit_sum(num):
    digitsum=0
    while(num>0):
        digitsum+=num%10
        num//=10
    return digitsum
num=int(input("enter a number"))
print("digit sum of",num,"is",digit_sum(num))
