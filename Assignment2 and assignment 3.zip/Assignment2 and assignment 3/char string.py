def char_string(s,char):
    count=0
    for c in s:
        if c==char:
            count+=1
    return count
s=str(input("enter the string"))
char=input("enter the character")
print(f"the character '{char}'appears in{char_string(s,char)}times in the string")

