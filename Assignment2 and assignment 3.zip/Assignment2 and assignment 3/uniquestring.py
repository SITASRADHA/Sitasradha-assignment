def are_chars_unique(s):
    return len(s) == len(set(s))

s = input("Enter a string: ")
if are_chars_unique(s):
    print("All characters are unique.")
else:
    print("Not all characters are unique.")