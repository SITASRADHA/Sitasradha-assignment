num=int(input("enter a number"))
if(num%3==0 and num%5==0):
    print("the number is divisible by 3&5")
else:
    print("the number is not divisible by 3&5")    