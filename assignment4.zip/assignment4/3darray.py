#create a 3d array of random integers
import numpy as np
arr=np.random.randint(0,100,size=(2,3,4))
print(arr)


           