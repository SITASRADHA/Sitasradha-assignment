#create a series using a python list
import pandas as pd
list_data=pd.array([1,2,3,4])
list_data_series=pd.Series(list_data)
print(list_data_series)