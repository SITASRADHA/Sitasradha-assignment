def word_count(s):
    words = s.split()
    word_count_dict = {}
    for word in words:
        word = word.lower()
        word = word.strip('.,!?;:')
        if word in word_count_dict:
            word_count_dict[word] += 1
        else:
            word_count_dict[word] = 1
    return word_count_dict

# Example usage:
my_string = "Hello world, this is a test string. Hello world!"
print("String:", my_string)
print("Word Count Dictionary:", word_count(my_string))