s=input("enter a string")
Ascii_values=[ord(char)for char in s]
print(Ascii_values)