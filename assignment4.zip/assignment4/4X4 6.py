#create a 4*4 identity matrix
import numpy as np
arr=np.eye(4)
print(arr)