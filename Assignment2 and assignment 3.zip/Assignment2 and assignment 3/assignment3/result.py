def product(*args):
    result=1
    for num in args:
        result*=num
    return result
print("product:",product(3,6,7,8))