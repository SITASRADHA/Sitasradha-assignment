num=int(input("enter a number"))
if(num%2==0 and num%3==0):
    print("no. is div by 2&3")
else:
    print("no.is no div by 2&3")    
