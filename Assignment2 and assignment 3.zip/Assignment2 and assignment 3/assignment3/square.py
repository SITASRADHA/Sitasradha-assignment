class Calculator:
    def square(self, num):
        return num ** 2

calculator = Calculator()
print(calculator.square(5))  