import numpy as np
def function(length,breadth):
    area=length*breadth
    print("area of rectangle is:",area)
function(23,67)    