num=123445
for i in range(10):
    count=str(num).count(str(i))
    if count>0:
     print(f"digit{i}appears{count}times") 