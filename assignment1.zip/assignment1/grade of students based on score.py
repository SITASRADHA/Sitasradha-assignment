score=int(input("enter the score of student"))
if(score>=90):
    print("A grade(excellent)")
elif(score>=80):
    print("B grade(best)") 
elif(score>=70):
    print("C grade(better)")
elif(score>=60):
    print("D grade(good)") 
elif(score>=50):
    print("E grade(average)")
elif(score>=40):
    print("F grade(bad or justpass)")
else:
    print("fail")  

