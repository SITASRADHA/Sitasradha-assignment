def even_list(numbers):
    for num in numbers:
        if num%2==0:
         print("even numbers",num)
        
        
        
numbers=input("enter number separated by space")
numbers=list(map(int,numbers.split()))
even_list(numbers)