
def count_case(s):
    uppercase_count = 0
    lowercase_count = 0
    for c in s:
        if c.isupper():
            uppercase_count += 1
        elif c.islower():
            lowercase_count += 1
    return uppercase_count, lowercase_count

# Example usage:
my_string = str(input("enter a string"))
print("String:", my_string)
uppercase, lowercase = count_case(my_string)
print("Uppercase Count:", uppercase)
print("Lowercase Count:", lowercase)