num=12345
reverse=0
while(num>0):
    remainder=num%10
    reverse=reverse*10+remainder
    num//=10
print("reverse of number:",reverse)    
