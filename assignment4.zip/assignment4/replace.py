#use np.where to replace the values
import numpy as np
arr=np.array([1,2,3,4,5,6,7,8,9,10])
print(arr)
arr1=np.where(arr>3,5,arr)
print(arr1)