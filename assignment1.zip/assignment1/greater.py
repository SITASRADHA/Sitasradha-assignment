a=int(input("enter 1st number"))
b=int(input("enter 2nd number"))
if(a>b):
    print("1st number is greater")
else:
    print("2nd number is greater")    