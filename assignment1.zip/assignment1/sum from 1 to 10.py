n=10
sum=n*(n+1)//2
print("sum:",sum)