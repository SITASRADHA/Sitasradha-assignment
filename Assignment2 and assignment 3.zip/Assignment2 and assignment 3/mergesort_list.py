def merge_sorted_list(list1,list2):
    return sorted(list1+list2)
my_list1=[3,4,5]
my_list2=[8,9,6]
print("merged list:",merge_sorted_list(my_list1,my_list2))
          
          