#retrive last 5 elements using .tail()
import pandas as pd
series=pd.Series([3,7,8,9,6,5,4,3])
retrive_series=series.tail(5)
print(retrive_series)
