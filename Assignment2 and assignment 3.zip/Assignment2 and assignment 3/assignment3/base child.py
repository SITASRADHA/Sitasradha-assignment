# Base class
class Animal:
    def _init_(self, name):
        self.name = name

    def speak(self):
        print(f"{self.name} makes a sound.")

# First derived class (inherits from Animal)
class Dog(Animal):
    def _init_(self, name, breed):
        super()._init_(name)
        self.breed = breed

    def bark(self):
        print(f"{self.name}, the {self.breed}, barks.")

# Second derived class (inherits from Dog)
class Puppy(Dog):
    def _init_(self, name, breed, age):
        super()._init_(name, breed)
        self.age = age

    def whine(self):
        print(f"{self.name} is a {self.age}-month-old puppy and whines softly.")

# Creating an object of the lowest class
puppy = Puppy("Buddy", "Golden Retriever", 3)

# Calling methods from all classes
puppy.speak()   # From Animal
puppy.bark()    # From Dog
puppy.whine()   # From Puppy