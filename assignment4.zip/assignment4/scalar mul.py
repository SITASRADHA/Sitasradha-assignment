#multiply a series by scalar
import pandas as pd
series=pd.Series([1,2,3,4])
scalar_series=2*series
print(scalar_series)