#find the max in each row
import numpy as np
arr=np.array([[1,2,3],[4,5,6],[7,8,9]])
print(arr)
max_values=np.max(arr,axis=1)
print(max_values)
