s="Hello World"
uppercase=sum(1 for c in s if c.isupper())
lowercase=sum(1 for c in s if c.islower())

print("uppaercase letters:",uppercase)
print("lowercase letters:",lowercase)