def is_palindrome(s):
    s = s.lower()  # Case-insensitive comparison
    return s == s[::-1]

# Example usage:
s = "madam"
if is_palindrome(s):
    print(s, "is a palindrome")
else:
    print(s, "is not a palindrome")