num1=int(input("enter 1st number"))
num2=int(input("enter 2nd number"))
print("addition of two numbers:",num1+num2)