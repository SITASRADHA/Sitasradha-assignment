#reverse of a numpy array
import numpy as np
arr=[1,2,3,4]
print("original array:",arr)
arr1=arr[::-1]
print(arr1)