class Animal:
    def _init_(self, name, age):
        self.name = name
        self.age = age

    def eat(self):
        print(f"{self.name} is eating")

    def sleep(self):
        print(f"{self.name} is sleeping")

class Dog(Animal):
    def _init_(self, name, age, breed):
        super()._init_(name, age)
        self.breed = breed

    def bark(self):
        print(f"{self.name} the {self.breed} is barking")

# Create a Dog object
dog = Dog("Max", 3, "Golden Retriever")

# Access Animal class methods
dog.eat()
dog.sleep()

# Access Dog class methods
dog.bark()

# Access attributes
print(f"Name: {dog.name}")
print(f"Age: {dog.age}")
print(f"Breed: {dog.breed}")