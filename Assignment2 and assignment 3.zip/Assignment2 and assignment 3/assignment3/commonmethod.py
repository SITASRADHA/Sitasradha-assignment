class Dog:
    def speak(self):
        print("The dog barks.")

class Cat:
    def speak(self):
        print("The cat meows.")

class Cow:
    def speak(self):
        print("The cow moos.")

# A common interface
def animal_sound(animal):
    animal.speak()

# Create different animal objects
dog = Dog()
cat = Cat()
cow = Cow()

# Call the same method on different objects
animal_sound(dog)  # Output: The dog barks.
animal_sound(cat)  # Output: The cat meows.
animal_sound(cow)  # Output: The cow moos.