#retrive first 5 elements using.head()method
import pandas as pd
series=pd.Series([3,7,8,9,6,5,4,3])
retrive_series=series.head(5)
print(retrive_series)
