class person:
    def __init__(self,name,age):
        self.name=name
        self.age=age
    def display_info(self):
        print(f"name:{self.name}")
        print(f"age:{self.age}")
person1=person("john",30)
person1.display_info()
        