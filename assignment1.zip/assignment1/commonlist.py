my_list1=[12,67,89,65]
my_list2=[78,87,65,43]
for i in my_list1:
    for j in my_list2:
        if(i==j):
            print(i)