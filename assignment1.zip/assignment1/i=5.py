i=5
while i>=1:
    print(i)
    i-=1