#use .multiply() method to multiply with scalar
import pandas as pd
series=pd.Series([1,6,7,8,4])
multiply_series=series.multiply(2)
print(multiply_series)