class Student():
    def _init_(self, name="Unknown", age=0):
        self.name = name
        self.age = age

    def display(self):
        print(f"Name: {self.name}, Age: {self.age}")


# Creating objects with different constructor arguments
s1 = Student()                     # No arguments
s2 = Student("Alice")             # Only name
s3 = Student("Bob", 20)           # Name and age

# Display student info
s1.display()  # Output: Name: Unknown, Age: 0
s2.display()  # Output: Name: Alice, Age: 0
s3.display()  # Output: Name: Bob, Age: 20