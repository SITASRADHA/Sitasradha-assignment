#replace nan with 0
import pandas as pd
import numpy as np
series=pd.Series([3,7,8,np.nan,6,5,np.nan,3])
fill0_series=series.fillna(0)
print(fill0_series)
