#filter series element greater than 50
import pandas as pd
series=pd.array([10,20,30,40,50,60,70,80,90,100])
filtered_series=series[series>50]
print(filtered_series)