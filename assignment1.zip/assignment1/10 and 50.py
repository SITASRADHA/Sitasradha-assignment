num=int(input("enter a number"))
if(num>=10 and num<=50):
    print("the number is in between 10 and 50")
else:
    print("the number is not in between 10 and 50")
        