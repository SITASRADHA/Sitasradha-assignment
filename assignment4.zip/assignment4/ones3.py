import numpy as np
arr=np.ones((2,2))
print(arr)