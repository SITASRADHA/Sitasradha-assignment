def rectangle(length,breadth):
    area=length*breadth
    return area
print("area of rectangle is:",rectangle(45,89))
