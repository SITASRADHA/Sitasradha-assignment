def element_index(lst):
    return [(element, index) for index, element in enumerate(lst)]

# Example usage:
my_list = ['a', 'b', 'c', 'd', 'e']
print("List:", my_list)
print("Element-Index Tuples:", element_index(my_list))