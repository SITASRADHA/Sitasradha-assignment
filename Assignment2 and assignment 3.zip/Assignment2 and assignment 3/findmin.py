def find_min(numbers):
    return min(numbers)
numbers=[7,9,6,1]
print("minimum numbers",find_min(numbers))
 