#create a string with custom string indices
import pandas as pd
custom_string={
    'a':"hello",
    'b':"world",
    'c':"!"
    }
print(custom_string['a'])
print(custom_string['b'])
print(custom_string['c'])
full_string=custom_string['a']+' '+custom_string['b']+custom_string['c']
print(full_string)