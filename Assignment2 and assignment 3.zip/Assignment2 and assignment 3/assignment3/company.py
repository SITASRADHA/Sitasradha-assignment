class Employee:
    company_name="ABC corporation"
    def __init__(self,name,age):
        self.name=name
        self.age=age
    def display_info(self):
        print(f"company name:{Employee.company_name}")
        print(f"name:{self.name}")
        print(f"age:{self.age}")
Employee1=Employee("john",30)
Employee1.display_info()
Employee2=Employee("joy",35)
Employee2.display_info()
        
        