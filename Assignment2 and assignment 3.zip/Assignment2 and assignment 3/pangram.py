import string

def is_pangram(sentence):
    alphabet = set(string.ascii_lowercase)
    sentence = set(sentence.lower())
    return alphabet.issubset(sentence)

# Example usage:
sentence = "The quick brown fox jumps over the lazy dog"
print("Sentence:", sentence)
print("Is Pangram:", is_pangram(sentence))