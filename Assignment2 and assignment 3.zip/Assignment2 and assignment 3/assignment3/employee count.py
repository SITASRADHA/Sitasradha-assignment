class Employee:
    # Class variable to count employees
    employee_count = 0

    def _init_(self, name, salary):
        self.name = name
        self.salary = salary
        Employee.employee_count += 1  # Increment count when an employee is created

    def display_employee(self):
        print(f"Name: {self.name}, Salary: {self.salary}")

    @classmethod
    def display_count(cls):
        print(f"Total number of employees: {cls.employee_count}")


# Create employee objects
emp1 = Employee("Alice", 50000)
emp2 = Employee("Bob", 60000)
emp3 = Employee("Charlie", 55000)

# Display individual employee details
emp1.display_employee()
emp2.display_employee()
emp3.display_employee()

# Display total number of employees
Employee.display_count()