#get the shape and dtype of array
import numpy as np
arr=np.array([1,2,3,4,5,6,7.8,9])
arr1=np.shape(arr)
print(arr1)
arr2=arr.dtype
print(arr2)