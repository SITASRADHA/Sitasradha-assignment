from abc import ABC, abstractmethod

# Abstract base class
class Animal(ABC):

    @abstractmethod
    def speak(self):
        pass  # No implementation here

# Subclass implementing the abstract method
class Dog(Animal):
    def speak(self):
        print("The dog barks.")

# Subclass implementing the abstract method
class Cat(Animal):
    def speak(self):
        print("The cat meows.")

# animal = Animal()  # ❌ This will raise an error (can't instantiate abstract class)

dog = Dog()
cat = Cat()

dog.speak()  # Output: The dog barks.
cat.speak()  # Output: The cat meows.