def longest(sentence):
    words=sentence.split()
    longest=max(words,key=len)
    return longest
sentence=str(input("enter the sentence"))
print("longest word in sentence:",longest(sentence))
