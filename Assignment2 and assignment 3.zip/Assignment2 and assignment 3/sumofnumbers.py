def sum_numbers(numbers):
    sum=0
    for num in numbers:
        sum+=num
    return sum
numbers=[9,7,8,5,76]
print("sum of numbers",sum_numbers(numbers))