# First parent class
class Flyable:
    def fly(self):
        print("This can fly.")

# Second parent class
class Swimmable:
    def swim(self):
        print("This can swim.")

# Child class inherits from both
class Duck(Flyable, Swimmable):
    def quack(self):
        print("The duck quacks.")

# Create object
d = Duck()

# Call methods from both parent classes
d.fly()     # Output: This can fly.
d.swim()    # Output: This can swim.
d.quack()   # Output: The duck quacks.