s=input("enter a string")
if s==s[::-1]:
    print(s,"is palindrome")
else:
    print(s,"is not a palindrome")    
   