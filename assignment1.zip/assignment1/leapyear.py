year=int(input("enter the year"))
if(year%4==0):
    print("this year is leap year")
else:
    print("this year is not leap year")