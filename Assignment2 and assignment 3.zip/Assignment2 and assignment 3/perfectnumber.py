def is_perfect_number(n):
    sum_divisors=0
    for i in range(1,n):
        if n%i==0:
         sum_divisors+=1
    return sum_divisors==n
n=int(input("enter a number"))
if is_perfect_number(n):
    print(n,"is perfect number")
else:
    print(n,"is not perfect number")
    