# create a 3*3 arrays with zeros
import numpy as np
arr=np.zeros((3,3))
print(arr)