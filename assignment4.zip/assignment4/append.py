#concatenate 2 series with append()
import pandas as pd
import numpy as np

# Create two Series
series1 = pd.Series([1, 2, 3])
series2 = pd.Series([4, 5, 6])

# Append series2 to series1
result = np.append([series1],[series2])
print(result)


