def celcius_to_farenhait(celcius):
    return (celcius*(9/5)+32)
celcius=int(input("enter the celcius in degree"))
farenhait=celcius_to_farenhait(celcius)
print(f"{celcius}degree c is equal to{farenhait}degree f")