#reshape 1d array to 2d array
import numpy as np
arr=np.array([1,2,3,4,5,6,7,8,9])
print(arr)
arr1=arr.reshape(3,3)
print(arr1)