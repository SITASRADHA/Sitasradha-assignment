#add two series with different indices
import pandas as pd
series1=pd.Series([1,2,3,4],index=['a','b','c','d'])
series2=pd.Series([5,6,7,8],index=['b','c','d','e'])
Add_series=series1.add(series2,fill_value=0)
print(Add_series)