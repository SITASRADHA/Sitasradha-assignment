def lcm(a,b):
    def gcd(a,b):
        while(b!=0):
            a,b=b,a%b
        return abs(a)
    return abs(a*b)//gcd(a,b)        
num1=int(input("enter first number"))
num2=int(input("enter second number"))
print("lcm of",num1,"and",num2,"is:",lcm(num1,num2))