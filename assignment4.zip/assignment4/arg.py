#get index of max and min values
import numpy as np
arr=np.array([(3,4,5),
              (5,6,7),
              (5,7,8)])
print(arr)
arr1=np.min(arr)
print(arr1)
arr2=np.argmin(arr)
print(arr2)
arr3=np.max(arr)
print(arr3)
arr4=np.argmax(arr)
print(arr4)