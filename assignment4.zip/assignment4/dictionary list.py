import pandas as pd
data={
    'a':1,
    'b':2,
    'c':3,
    'd':4
    }
data_series=pd.Series(data)
print(data_series)