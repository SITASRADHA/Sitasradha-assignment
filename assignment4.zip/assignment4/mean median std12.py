#compute the mean,std&median of an array
import numpy as np
arr=np.array([1,2,3,4,5,6,7,8,9])
print(arr)
arr1=np.mean(arr)
print(arr1)
arr2=np.median(arr)
print(arr2)
arr3=np.std(arr)
print(arr3)