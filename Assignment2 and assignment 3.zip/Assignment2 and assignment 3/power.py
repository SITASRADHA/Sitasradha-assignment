def power(base,exponent):
    if exponent==0:
        return 1
    elif exponent<1:
        return 1/power(base,-exponent)
    else:
        return base*power(base,exponent-1)
base=float(input("enter the base number:"))
exponent=int(input("enter the exponent:"))
print(base,"raised to the power of",exponent,"is:",power(base,exponent))