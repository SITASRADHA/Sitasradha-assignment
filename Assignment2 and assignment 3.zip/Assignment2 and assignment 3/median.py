def calculate_median(lst):
    sorted_list = sorted(lst)
    n = len(sorted_list)
    if n % 2 == 0:
        median = (sorted_list[n // 2 - 1] + sorted_list[n // 2]) / 2
    else:
        median = sorted_list[n // 2]
    return median

# Example usage:
my_list = [1, 3, 5, 2, 4]
print("List:", my_list)
print("Median:", calculate_median(my_list))