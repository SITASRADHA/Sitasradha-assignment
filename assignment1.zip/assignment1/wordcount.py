s=input("enter the sentence")
count=0
for char in s:
    count+=1
print("count of words",count)