my_list=[1,2,3,4,5]
for i in range(len(my_list)):
    print(my_list[i])