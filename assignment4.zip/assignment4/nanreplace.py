#replace NaN with column means
import numpy as np
arr=np.array([(1,2,3),
              (4,np.nan,9),
              (np.nan,5,6)])
print(arr)
arr1=np.nanmean(arr,axis=0)
print(arr1)
arr2=np.where(arr)
print(arr2)