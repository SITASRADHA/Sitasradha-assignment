class BankAccount:
    def _init_(self, account_holder, balance=0):
        self.account_holder = account_holder
        self.balance = balance

    def deposit(self, amount):
        if amount > 0:
            self.balance += amount
            print(f"Deposited ${amount}. New balance: ${self.balance}")
        else:
            print("Deposit amount must be positive.")

    def withdraw(self, amount):
        if amount <= 0:
            print("Withdrawal amount must be positive.")
        elif amount > self.balance:
            print("Insufficient balance.")
        else:
            self.balance -= amount
            print(f"Withdrew ${amount}. New balance: ${self.balance}")

    def display_balance(self):
        print(f"Account holder: {self.account_holder}, Balance: ${self.balance}")


# Example usage
account = BankAccount("John Doe", 1000)
account.display_balance()

account.deposit(500)
account.withdraw(200)
account.withdraw(2000)  # Should show insufficient balance
account.deposit(-50)    # Should show invalid deposit
account.display_balance()