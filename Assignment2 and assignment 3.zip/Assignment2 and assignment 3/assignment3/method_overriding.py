# Parent class
class Animal:
    def speak(self):
        print("The animal makes a sound.")

# Child class
class Dog(Animal):
    def speak(self):
        print("The dog barks.")

# Child class
class Cat(Animal):
    def speak(self):
        print("The cat meows.")

# Create objects
animal = Animal()
dog = Dog()
cat = Cat()

# Call the overridden methods
animal.speak()  # Output: The animal makes a sound.
dog.speak()     # Output: The dog barks.
cat.speak()     # Output: The cat meows.