def frequency_list(lst):
    return max(set(lst),key=lst.count)
my_list=[1,3,5,5,5,7,7,7,8,8,9,5,5,2,2]
print("list:",my_list)
print("frequency of list:",frequency_list(my_list))