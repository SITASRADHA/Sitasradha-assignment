#access first 3 elements of a list
import pandas as pd
list_series=pd.Series([1,2,3,4])
first_three=list_series.head(3)
print(first_three)