#create 5 even numbers from 0 to 1
import numpy as np
arr=np.linspace(0.2,1,5)
print(arr)