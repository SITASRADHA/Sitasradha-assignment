s=input("enter a string")
vowels="aeiouAEIOU"
count=0
for char in s:
    if char in vowels:
        print(char) 
        count+=1
print("count of vowels:",count)