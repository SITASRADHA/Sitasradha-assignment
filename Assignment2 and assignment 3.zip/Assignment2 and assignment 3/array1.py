import numpy as np
arr=np.array([3,5,7,8,9,5,7,8,7])
ary=np.array([3,4,6,7,8,9,3,2])
print(np.concatenate((arr,ary)))