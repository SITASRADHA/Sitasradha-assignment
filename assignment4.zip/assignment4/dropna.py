#drop missing values
import pandas as pd
import numpy as np
series=pd.Series([3,7,8,np.nan,6,5,np.nan,3])
drop_series=series.dropna()
print(drop_series)
