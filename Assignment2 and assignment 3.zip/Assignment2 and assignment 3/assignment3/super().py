
# Parent class
class Animal:
    def speak(self):
        print("The animal makes a sound.")

# Child class
class Dog(Animal):
    def speak(self):
        super().speak()  # Call the method from the parent class
        print("The dog barks.")

# Create object
dog = Dog()
dog.speak()