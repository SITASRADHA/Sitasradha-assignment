from functools import reduce

def reverse_string(s):
    return reduce(lambda x,y:y+x,s)
s=str(input("enter a string"))
print("original string:",s)
print("reversed string:",reverse_string(s))