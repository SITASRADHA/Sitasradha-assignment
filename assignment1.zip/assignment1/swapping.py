a=int(input("enter 1st number"))
b=int(input("enter 2nd number"))

print("before swap a=",a,"before swap b=",b)
temp=a
a=b
b=temp
print("after swap a=",a,"after swap b=",b)