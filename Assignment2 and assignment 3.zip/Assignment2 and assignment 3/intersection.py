def intersection(list1,list2):
    return list(set(list1) &set(list2))
my_list1=[5,6,8,9,7,6,5,4]
my_list2=[5,6,7,8,4,3,2,1]
print("list1:",my_list1)
print("list2:",my_list2)
print("intersection of two list:",intersection(my_list1,my_list2))