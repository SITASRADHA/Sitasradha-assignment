class Person:
    def _init_(self, name, age):
        self.name = name
        self.age = age

class Employee(Person):
    def _init_(self, name, age, employee_id):
        super()._init_(name, age)
        self.employee_id = employee_id

# Create objects
person = Person("John Doe", 30)
employee = Employee("Jane Doe", 25, "E123")

# Use isinstance
print(isinstance(person, Person))  # Output: True
print(isinstance(person, Employee))  # Output: False
print(isinstance(employee, Person))  # Output: True
print(isinstance(employee, Employee))  # Output: True