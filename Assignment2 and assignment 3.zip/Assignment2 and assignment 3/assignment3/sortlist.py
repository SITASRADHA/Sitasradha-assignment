def is_sorted(lst):
    return lst==sorted(lst)
my_list1=[1,2,3,4]
print("list:",my_list1)
print("is list sorted?",is_sorted(my_list1))
my_list2=[2,1,3,4]
print("list:",my_list2)
print("is list sorted?",is_sorted(my_list2))