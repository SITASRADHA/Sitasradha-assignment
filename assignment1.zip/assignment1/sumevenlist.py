my_list=[1,76,89,5,45,78]
sum_even=0
for num in my_list:
    if(num%2==0):
        sum_even+=num
print("sum of even numbers in list:",sum_even)

