#sort series by index
import pandas as pd
series=pd.Series([4,7,8,9,5,2,6,9],index=['a','c','b','d','e','f','g','h'])
sorted_series=series.sort_index()
print(sorted_series)