def average(numbers):
    sum=0
    for n in numbers:
        sum+=n
        avg=sum/len(numbers)
    return avg
n=[4,7,8]
print("average of numbers:",average(n))