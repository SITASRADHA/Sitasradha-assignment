def second_largest(numbers):
    numbers=list(set(numbers))
    numbers.sort(reverse=True)
    if len(numbers)<2:
        return None
    return numbers[1]
numbers=[8,7,6,9,4,9,9,9,9,8,7,8,4,3,2,2,1]
print(second_largest(numbers))