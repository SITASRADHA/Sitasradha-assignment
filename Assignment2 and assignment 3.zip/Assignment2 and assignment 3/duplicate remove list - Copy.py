def remove_duplicate(lst):
    return list(set(lst))
my_list=input("enter the numbers separated by space")
my_list=list(map(int,my_list.split()))
print("original list:",my_list)
print("after remove duplicate list:",remove_duplicate(my_list))