
my_list=[10,67,54,3,87,45,98,32,6]
max_value=my_list[0]
for num in my_list:
    if num>max_value:
        max_value=num
print("maximum value in list:",max_value)
     