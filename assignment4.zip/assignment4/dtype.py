#check series datatype
import pandas as pd
import numpy as np
series=pd.Series([3,7,8,7,6,5,8,3])
print(series.dtype)
