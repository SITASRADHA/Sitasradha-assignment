class Person:
    def _init_(self, name, age):
        self.__name = name      # private attribute
        self.__age = age        # private attribute

    # Getter for name
    def get_name(self):
        return self.__name

    # Setter for name
    def set_name(self, name):
        self.__name = name

    # Getter for age
    def get_age(self):
        return self.__age

    # Setter for age
    def set_age(self, age):
        if age > 0:
            self.__age = age
        else:
            print("Age must be positive.")

# Create object
p = Person("Alice", 25)

# Access data using getters
print("Name:", p.get_name())   # Output: Name: Alice
print("Age:", p.get_age())     # Output: Age: 25

# Modify data using setters
p.set_name("Bob")
p.set_age(30)

# Display updated values
print("Updated Name:", p.get_name())   # Output: Updated Name: Bob
print("Updated Age:", p.get_age())     # Output: Updated Age: 30

# Try to set invalid age
p.set_age(-5)  # Output: Age must be positive.