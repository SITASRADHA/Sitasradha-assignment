def find_index(lst,value):
    try:
        return lst.index(value)
    except valueerror:
        return -1
my_list=[1,2,3]
print("list:",my_list)
print("index of 3:",find_index(my_list,3))
print("index of 2:",find_index(my_list,2))
