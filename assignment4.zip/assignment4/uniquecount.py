#find the unique values and their counts
import numpy as np
arr=np.array([1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9])
print(arr)
arr1=np.unique(arr)
print(arr1)
count=np.size(arr1)
print(count)
counts=np.size(arr)
print(counts)
values,count=np.unique(arr,return_counts=True)
print("values are:",values,"counts:",count)
