def vowels_strings(s):
    count=0
    vowels="aeiouAEIOU"
    for char in s:
        if char in vowels:
            count+=1
    return count
       
s=str(input("enter a string"))
print("number of vowels",vowels_strings(s))
